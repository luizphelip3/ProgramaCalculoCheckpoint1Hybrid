package com.example.checkpoint1

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import android.widget.ArrayAdapter
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import kotlinx.android.synthetic.main.activity_calculadora.*
import kotlinx.android.synthetic.main.activity_main.*
import java.text.DecimalFormat

class ActivityCalculadora : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_calculadora)

        //função para designar o clique no botão
        btnCalcular.setOnClickListener {
            //variáveis necessárias para dar valor aos números utilizados nas operações
            val txtNum1: Double = txtNum1.text.toString().toDouble()
            val txtNum2: Double = txtNum2.text.toString().toDouble()
            //variável que executa e recebe os dados da função
            val resultado: Double = operacao(txtNum1, txtNum2)
            //Formatação do número recebido: vai declarar somente duas casas depois da vírgula
            val decFormat = DecimalFormat("#.00")
            Toast.makeText(applicationContext,"O resultado da operação é: ${decFormat.format(resultado)}", Toast.LENGTH_LONG).show()
        }
    }

    fun operacao(numero1: Double, numero2: Double) : Double{
        return when (rdgOpcoes.checkedRadioButtonId){
            R.id.rdbSoma -> numero1 + numero2
            R.id.rdbSubtracao -> numero1 - numero2
            R.id.rdbMultiplicacao -> numero1 * numero2
            else -> numero1 / numero2
        }
    }
}