package com.example.checkpoint1

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import kotlinx.android.synthetic.main.activity_conta.*
import java.text.DecimalFormat

class ActivityConta : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_conta)

        //função ao clicar o botão
        btnCalcularConta.setOnClickListener{
            //variáveis recebidas pelo usuário
            val precoAssinatura: Double =  precoAssinatura.text.toString().toDouble()
            val numChamadaCelular: Double = numChamadaCelular.text.toString().toDouble()
            val numChamadaLocal: Double = numChamadaLocal.text.toString().toDouble()

            //operações executadas com os dados das variaveis recebidas pelo usuario
            val resultadoChamadaLocal : Double = numChamadaLocal * 0.04
            val resultadoChamadaCelular : Double =  numChamadaCelular * 0.20
            val resultadoTotal: Double = resultadoChamadaCelular  + resultadoChamadaLocal +  precoAssinatura

            //formatação dos valores
            var mensagemAssinatura = "Assinatura: ${precoAssinatura}"
            var mensagemChamadaLocal = "Chamada Local: ${resultadoChamadaLocal}"
            var mensagemChamadaCelular=  "Chamada Celular: ${resultadoChamadaCelular}"
            var mensagemTotal = " Valor total: ${resultadoTotal}"

            //formatação da mensagem com os valores
            var msg = """${mensagemAssinatura}
                |${mensagemChamadaLocal}
                |${mensagemChamadaCelular}
                |
                |${mensagemTotal} """.trimIndent().trimMargin("|")

            //função que guarda a mensagem completa e leva para outra tela
            var intentResultado = Intent(this, ResultadoContaActivity::class.java)
            intentResultado.putExtra("msg", msg)
            startActivity(intentResultado)
        }

    }
}

