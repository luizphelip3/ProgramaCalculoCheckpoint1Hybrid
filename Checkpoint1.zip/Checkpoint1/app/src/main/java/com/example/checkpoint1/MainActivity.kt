package com.example.checkpoint1

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import android.widget.ArrayAdapter
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import kotlinx.android.synthetic.main.activity_main.*

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

    }

    //função que leva à outra activity ao clicar na opção de calculadora
    fun cliqueCalculadora(view: View){
        var intentCalculadora = Intent(this, ActivityCalculadora::class.java)
        startActivity(intentCalculadora)
    }

    //função que leva à outra activity ao clicar na opção de conta telefônica
    fun cliqueConta(view: View){
        var intentConta = Intent(this, ActivityConta::class.java)
        startActivity(intentConta)
    }

    //função que leva à outra activity ao clicar na opção de integrantes
    fun cliqueIntegrantes(view: View) {
        val builder = AlertDialog.Builder (this)
        builder.setTitle("Desenvolvido por")
        builder.setMessage("Luiz Phelipe Silva de Almeida")
        builder.setNegativeButton("Fechar", null)
        builder.create().show()
    }
}